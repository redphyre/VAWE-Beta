<? unset($_SESSION['user']);
	unset($_SESSION['login']);
	echo "Reset Complete.";
?>