<?
if ($_SESSION['user']) {
	print_r("true");
}
else { print_r("false"); }
?>